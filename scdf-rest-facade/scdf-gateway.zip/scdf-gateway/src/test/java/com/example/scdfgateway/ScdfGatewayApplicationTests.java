package com.example.scdfgateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ScdfGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
